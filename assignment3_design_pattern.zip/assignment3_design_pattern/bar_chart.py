from abstract_chart_maker import AbstractChartMaker
import matplotlib.pyplot as plt


class BarChart(AbstractChartMaker):
    def create(self, data):
        name_list = ["Class", "Attribute", "Method"]
        numbers = data
        size = range(len(numbers))
        plt.bar(size, numbers, tick_label=name_list)
        plt.ylabel("Number")
        plt.xlabel("Elements of UML")
        plt.title("The total counts for three elements of the UML")
        plt.show()
