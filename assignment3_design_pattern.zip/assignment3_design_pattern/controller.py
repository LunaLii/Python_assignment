from file_handler import FileHandler
from chart import Chart
from bar_chart import BarChart
from line_graph import LineGraph
from pie_chart import PieChart
from os import path
from txt_reader import TxtReader
from word_reader import WordReader


class Controller:
    file = FileHandler()

    @staticmethod
    def get_file_content(infile):
        file_content = []
        if ".txt" in infile[-4:]:
            file_reader = TxtReader()
            file_content = file_reader.get_file_content(infile)
        elif ".docx" in infile[-5:]:
            file_reader = WordReader()
            file_content = file_reader.get_file_content(infile)
        return file_content

    @staticmethod
    def load_file(infile):
        try:
            if path.isfile(infile):
                if ".txt" or ".docx" in infile:
                    file_content = Controller.get_file_content(infile)
                    Controller.file.class_handler(file_content)
                    Controller.file.find_classes()
                    return True
                else:
                    raise NameError
            else:
                raise FileNotFoundError

        except NameError:
            print("Incorrect file type, please check with help load")
        except FileNotFoundError:
            print("File is not found")
        except Exception as e:
            print(e)

    def save_file(self, file_location):
        try:
            if path.exists(file_location):
                self.file.output_file(file_location)
                print("created")
            else:
                raise FileNotFoundError
        except FileNotFoundError:
            print("No such directory")
        except Exception as e:
            print(e)

    @staticmethod
    def get_chart_data():
        class_num = len(Controller.file.all_my_classes)
        attribute_num = 0
        method_num = 0
        for x in Controller.file.all_my_classes:
            attribute_num += x.get_attribute_length()
            method_num += x.get_method_length()
        data = [class_num, attribute_num, method_num]
        return data

    def create_bar_chart(self):
        data = self.get_chart_data()
        if data == [0, 0, 0]:
            return False
        else:
            chart = Chart(BarChart())
            chart.create_chart(data)

    def create_pie_chart(self):
        data = self.get_chart_data()
        # self.chart.create_pie_chart(data)
        chart = Chart(PieChart())
        chart.create_chart(data)

    def create_line_chart(self):
        data = self.get_chart_data()
        # self.chart.create_line_graph(data)
        chart = Chart(LineGraph())
        chart.create_chart(data)


if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)
