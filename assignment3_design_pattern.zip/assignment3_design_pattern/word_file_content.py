from docx import Document
from file_content import FileContent


class WordFileContent(FileContent):
    def open_file(self, file_name):
        file = Document(file_name)
        content = []
        for para in file.paragraphs:
            content.append(para.text + "\n")
        return content
