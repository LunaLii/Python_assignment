from file_reader import FileReader
from txt_file_content import TxtFileContent


class TxtReader(FileReader):
    def get_file_type(self, file_name):
        return TxtFileContent()
