from abc import ABCMeta, abstractmethod


class AbstractChartMaker(metaclass=ABCMeta):
    @abstractmethod
    def create(self, data):
        pass
