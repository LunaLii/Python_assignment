import unittest
from file_handler import FileHandler
from txt_reader import TxtReader
from word_reader import WordReader


class FilerUnitTest(unittest.TestCase):
    def setUp(self):
        self.file = FileHandler()

    def test_read_word_file(self):
        file_reader = WordReader()
        actual = file_reader.get_file_content("C:\\Users\\Luna\\PycharmProjec"
                                              "ts\\assignment2_refactoring\\"
                                              "test\\test2.docx")
        expect = ["@startuml\n", "ToyBox *-- Toy\n", "\n", "class ToyBox {\n",
                  "    name : String\n", "}\n", "\n", "class Toy {\n", "}\n",
                  "@enduml\n"]
        self.assertEqual(expect, actual, "cannot read word file")

    def test_read_txt_file(self):
        file_reader = TxtReader()
        actual = file_reader.get_file_content("C:\\Users\\Luna\\PycharmProjec"
                                              "ts\\assignment2_refactoring\\"
                                              "test\\test2.txt")
        expect = ["@startuml\n", "ToyBox *-- Toy\n", "\n", "class ToyBox {\n",
                  "    name : String\n", "}\n", "\n", "class Toy {\n", "}\n",
                  "@enduml\n"]
        self.assertEqual(expect, actual, "cannot read txt file")

    def test_get_method_name(self):
        file_reader = WordReader()
        file_content = file_reader.get_file_content("C:\\Users\\Luna\\Pycharm"
                                                    "Projects\\assignment2_"
                                                    "refactoring\\test\\"
                                                    "uml.docx")
        self.file.class_handler(file_content)
        self.file.find_classes()
        actual_one = []
        class_one = self.file.all_my_classes[0]
        for i in class_one.all_my_methods:
            actual_one.append(i.name)
        expected_one = ["add_toy", "get_toys"]
        class_two = self.file.all_my_classes[1]
        actual_two = []
        for i in class_two.all_my_methods:
            actual_two.append(i.name)
        expected_two = ["__str__"]
        self.assertEqual(expected_one, actual_one, "cannot get method name")
        self.assertEqual(expected_two, actual_two, "cannot get method name")

    def test_get_class_name(self):
        file_reader = WordReader()
        file_content = file_reader.get_file_content("C:\\Users\\Luna\\Pycharm"
                                                    "Projects\\assignment2_"
                                                    "refactoring\\test\\"
                                                    "uml.docx")
        self.file.class_handler(file_content)
        self.file.find_classes()
        actual = []
        for x in self.file.all_my_classes:
            actual.append(x.name)
        expected = ["ToyBox", "Toy"]
        self.assertEqual(expected, actual, "cannot get class name")

    def test_get_attribute_name(self):
        file_reader = WordReader()
        file_content = file_reader.get_file_content("C:\\Users\\Luna\\Pycharm"
                                                    "Projects\\assignment2_"
                                                    "refactoring\\test\\"
                                                    "uml.docx")
        self.file.class_handler(file_content)
        self.file.find_classes()
        actual_one = []
        class_one = self.file.all_my_classes[0]
        for i in class_one.all_my_attributes:
            actual_one.append(i.name)
        expected_one = ["number", "allMyToys"]
        class_two = self.file.all_my_classes[1]
        actual_two = []
        for i in class_two.all_my_attributes:
            actual_two.append(i.name)
        expected_two = ["name", "color", "price"]
        self.assertEqual(expected_one, actual_one, "cannot get attribute name")
        self.assertEqual(expected_two, actual_two, "cannot get attribute name")

    def test_get_relationship_one_composition(self):
        file_reader = TxtReader()
        file_content = file_reader.get_file_content("C:\\Users\\Luna\\Pycharm"
                                                    "Projects\\assignment2_re"
                                                    "factoring\\test\\test_re"
                                                    "lationship.txt")
        self.file.class_handler(file_content)
        self.file.find_classes()
        class_two = self.file.all_my_classes[1]
        actual = []
        for i in class_two.all_my_relationships:
            i.identify_relationship_type()
            actual.append(i.compo_1_to_1)
        expected = [[], [], ['ClassB'], [], []]
        self.assertEqual(expected, actual, "cannot get 1 to 1 composition")

    def test_get_relationship_many_composition(self):
        file_reader = TxtReader()
        file_content = file_reader.get_file_content("C:\\Users\\Luna\\Pycharm"
                                                    "Projects\\assignment2_re"
                                                    "factoring\\test\\test_re"
                                                    "lationship.txt")
        self.file.class_handler(file_content)
        self.file.find_classes()
        class_two = self.file.all_my_classes[1]
        actual = []
        for i in class_two.all_my_relationships:
            i.identify_relationship_type()
            actual.append(i.compo_1_to_many)
        expected = [[], ["Toy"], [], [], []]
        self.assertEqual(expected, actual, "cannot get 1 to many composition")

    def test_get_relationship_many_aggregation(self):
        file_reader = TxtReader()
        file_content = file_reader.get_file_content("C:\\Users\\Luna\\Pycharm"
                                                    "Projects\\assignment2_re"
                                                    "factoring\\test\\test_re"
                                                    "lationship.txt")
        self.file.class_handler(file_content)
        self.file.find_classes()
        class_two = self.file.all_my_classes[1]
        actual = []
        for i in class_two.all_my_relationships:
            i.identify_relationship_type()
            actual.append(i.aggr_1_to_many)
        expected = [[], [], [], ['ClassD'], []]
        self.assertEqual(expected, actual, "cannot get 1 to many aggregation")

    def test_get_relationship_one_aggregation(self):
        file_reader = TxtReader()
        file_content = file_reader.get_file_content("C:\\Users\\Luna\\Pycharm"
                                                    "Projects\\assignment2_re"
                                                    "factoring\\test\\test_re"
                                                    "lationship.txt")
        self.file.class_handler(file_content)
        self.file.find_classes()
        class_two = self.file.all_my_classes[1]
        actual = []
        for i in class_two.all_my_relationships:
            i.identify_relationship_type()
            actual.append(i.aggr_1_to_1)
        expected = [[], [], [], [], ['ClassF']]
        self.assertEqual(expected, actual, "cannot get 1 to 1 aggregation")

    def test_get_relationship_dependency(self):
        file_reader = TxtReader()
        file_content = file_reader.get_file_content("C:\\Users\\Luna\\Pycharm"
                                                    "Projects\\assignment2_re"
                                                    "factoring\\test\\test_re"
                                                    "lationship.txt")
        self.file.class_handler(file_content)
        self.file.find_classes()
        class_two = self.file.all_my_classes[1]
        actual = []
        for i in class_two.all_my_relationships:
            i.identify_relationship_type()
            actual.append(i.dependency_list)
        expected = [["Controller"], [], [], [], []]
        self.assertEqual(expected, actual, "cannot get dependency")

    def test_get_relationship_association(self):
        file_reader = TxtReader()
        file_content = file_reader.get_file_content("C:\\Users\\Luna\\Pycharm"
                                                    "Projects\\assignment2_re"
                                                    "factoring\\test\\test_re"
                                                    "lationship.txt")
        self.file.class_handler(file_content)
        self.file.find_classes()
        class_one = self.file.all_my_classes[0]
        actual = []
        for i in class_one.all_my_relationships:
            i.identify_relationship_type()
            actual.append(i.association_list)
        expected = [["Command"]]
        self.assertEqual(expected, actual, "cannot get association")
