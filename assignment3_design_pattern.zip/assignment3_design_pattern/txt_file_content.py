from file_content import FileContent


class TxtFileContent(FileContent):
    def open_file(self, file_name):
        file = open(file_name, 'r').readlines()
        return file
