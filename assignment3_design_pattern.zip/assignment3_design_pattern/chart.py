class Chart(object):
    def __init__(self, chart_type):
        self.chart_type = chart_type

    def create_chart(self, data):
        self.chart_type.create(data)
