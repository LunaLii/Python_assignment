from abc import ABCMeta, abstractmethod


class FileContent(metaclass=ABCMeta):
    @abstractmethod
    def open_file(self, file_name):
        pass
