from abc import ABCMeta, abstractmethod


class FileReader(metaclass=ABCMeta):
    @abstractmethod
    def get_file_type(self, file_name):
        pass

    def get_file_content(self, file_name):
        file = self.get_file_type(file_name)
        return file.open_file(file_name)
