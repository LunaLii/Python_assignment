from abstract_chart_maker import AbstractChartMaker
import matplotlib.pyplot as plt


class LineGraph(AbstractChartMaker):
    def create(self, data):
        plt.title('Number of Classes, Attributes and Methods')
        plt.xlabel('1: Classes, 2: Attributes, 3: Methods')
        plt.ylabel('Total counts for each: (classes, attributes, methods)')
        x = [1, 2, 3]
        y = data
        plt.plot(x, y)
        plt.show()
