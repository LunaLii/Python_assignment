from file_reader import FileReader
from word_file_content import WordFileContent


class WordReader(FileReader):
    def get_file_type(self, file_name):
        return WordFileContent()
